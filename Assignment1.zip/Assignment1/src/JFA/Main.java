package JFA;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

	public static void main(String[] args)
	{
		//Problem 1
		/*LinkedList<Integer> listobj = new LinkedList<Integer>();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size");
		int size = scan.nextInt();
		for (int i = 1; i <= size; i++) {
			System.out.println("Enter a number");
			int number = scan.nextInt();
			listobj.add(number);
		}
		
		LinkedList<Integer> perfectNumberList = AssignmentProblem1.PerfectNumber(listobj);

		System.out.println("Below are the perfect numbers");
		for (int i = 0; i < perfectNumberList.size(); i++) {

			System.out.println(perfectNumberList.get(i));
		}
		
		//Problem 3
		ArrayList<Integer> arrayObj = new ArrayList<Integer>();
		System.out.println("enter the size of an array");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		for (int i = 1; i <= size; i++) {
			System.out.println("Enter a number");
			int number = scan.nextInt();
			arrayObj.add(number);
		}
		int maxNumber = AssignmentProblem3.maximumNumber(arrayObj);
		System.out.println(maxNumber);
		
		//Problem 4
		
		ArrayList<String> arrayObj = new ArrayList<String>();
		System.out.println("enter the size of an array");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		for (int i = 1; i <= size; i++) {
			System.out.println("Enter a String");
			String arrayString = scan.next();
			arrayObj.add(arrayString);
		}
		
		ArrayList<String> a2=AssignmentProblem4.sort(arrayObj);
		
		for(int i=0;i<a2.size();i++)
		{
			System.out.println(a2.get(i));
		}
		
		//Problem 5
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a string");
		
		String expression=scan.next();
		if (AssignmentProblem5.areBracketsBalanced(expression))
            System.out.println("Balanced ");
        else
            System.out.println("Not Balanced ");*/
		
		//Problem7
		Scanner scan = new Scanner(System.in);
		Queue<Integer> queueObj = new LinkedList<Integer>();
		System.out.println("Enter the size");
		int size = scan.nextInt();

		for (int i = 0; i < size; i++) {
			int number = scan.nextInt();
			queueObj.add(number);
		}
		StringBuilder s = new StringBuilder();

		for (Integer item : queueObj) {
			s.append(item);
		}
		int number=Integer.parseInt(s.toString());
		
		int decimalValue=Assignmentproblem7.binaryToDecimal(number);
		System.out.println(decimalValue);

	}
}
