package JFA;

import java.util.ArrayList;

public class AssignmentProblem3 {
	public static int maximumNumber(ArrayList<Integer> arrayObj) {
		int maxNumber = Integer.MIN_VALUE;
		for (int i = 0; i < arrayObj.size(); i++) {
			if (maxNumber < arrayObj.get(i)) {
				maxNumber = arrayObj.get(i);
			}
		}
		return maxNumber;
	}
}
