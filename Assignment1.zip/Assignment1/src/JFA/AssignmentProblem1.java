package JFA;

import java.util.LinkedList;

public class AssignmentProblem1 {
	
	public static LinkedList<Integer> PerfectNumber(LinkedList<Integer> listobj) {
		LinkedList<Integer> perfectNumberListObj = new LinkedList<Integer>();

		for (int i = 0; i < listobj.size(); i++) {
			int number = listobj.get(i);
			int sum = 0;
			for (int j = 1; j < number; j++) {
				if (number % j == 0) {
					sum = sum + j;
				}
			}

			if (sum == number) {
				perfectNumberListObj.add(number);
			}
		}
		return perfectNumberListObj;
	}

}
