package JFA;

import java.util.ArrayList;

public class AssignmentProblem4 {
	public static ArrayList<String> sort(ArrayList<String> arrayObj)
	{
		int n=arrayObj.size();
		
	    for (int i=0 ;i<n; i++)
	    {
	        String temp = arrayObj.get(i);
	 
	        // Insert s[j] at its correct position
	        int j = i - 1;
	        while (j >= 0 && temp.length() < arrayObj.get(j).length())
	        {
	            arrayObj.set(j+1, arrayObj.get(j));
	            j--;
	        }
	        arrayObj.set(j+1, temp);
	    }
	    return arrayObj;
	}
}
